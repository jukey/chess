Chess images from http://commons.wikimedia.org/wiki/Category:SVG_chess_pieces
by Colin M.L. Burnett; licensed under GFDL (www.gnu.org/copyleft/fdl.html),
CC-BY-SA-3.0 (www.creativecommons.org/licenses/by-sa/3.0/) or
GPL (www.gnu.org/licenses/gpl.html)], via Wikimedia Commons.
