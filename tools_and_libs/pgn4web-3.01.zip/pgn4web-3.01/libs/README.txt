The libs folder contains third party libraries used by the pgn4web pages.
Please refer to the readme and license files in each subfolder for more
information on each library.
