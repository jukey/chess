THE GARBOCHESS CHESS ENGINE

GarboChess is a javascript chess engine licensed by Gary Linscott under BSD
license, see LICENSE file.

Homepage: http://forwardcoding.com/projects/ajaxchess/chess.html
Repository: https://github.com/glinscott/Garbochess-JS/


IMPLEMENTATION NOTES

Please note that GarboChess is processor intensive; in order to optimize
computing resources, the analysis of each board is limited to a short time.
